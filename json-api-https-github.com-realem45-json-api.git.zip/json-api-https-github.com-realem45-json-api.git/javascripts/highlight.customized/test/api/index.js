'use strict';

describe('hljs', function() {
  require('./highlightAuto');
  require('./ident');
  require('./underscoreIdent');
  require('./number');
  require('./cNumber');
  require('./binaryNumber');
  require('./starters');
  require('./getLanguage');
});
